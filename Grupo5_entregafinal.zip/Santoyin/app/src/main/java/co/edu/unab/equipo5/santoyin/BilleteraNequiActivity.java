package co.edu.unab.equipo5.santoyin;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class BilleteraNequiActivity extends AppCompatActivity {

    private TextView saldoTextView;
    private TextView horasSeleccionadasLabel;
    private SeekBar seekBarHoras;
    private Button btnComprarHoras;
    private Button btnIrAlMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.billetera_nequi);

        saldoTextView = findViewById(R.id.saldoTextView);
        horasSeleccionadasLabel = findViewById(R.id.horasSeleccionadasLabel);
        seekBarHoras = findViewById(R.id.seekBarHoras);
        btnComprarHoras = findViewById(R.id.btn_comprar_horas);
        btnIrAlMenu = findViewById(R.id.btn_ir_al_menu);

        // Usar un array para permitir la mutación del saldo
        final int[] saldo = {90000};
        saldoTextView.setText("$ " + saldo[0]);

        seekBarHoras.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                horasSeleccionadasLabel.setText(progress + " horas seleccionadas");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No se requiere implementación
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // No se requiere implementación
            }
        });

        btnComprarHoras.setOnClickListener(view -> {
            int horasSeleccionadas = seekBarHoras.getProgress();
            int costoTotal = horasSeleccionadas * 5000;

            if (saldo[0] >= costoTotal) {
                saldo[0] -= costoTotal;
                saldoTextView.setText("$ " + saldo[0]);
                // Aquí puedes agregar la lógica para guardar la nueva información del saldo y las horas compradas
            } else {
                // Mostrar mensaje de saldo insuficiente
                Toast.makeText(BilleteraNequiActivity.this, "Saldo insuficiente", Toast.LENGTH_SHORT).show();
            }
        });

        btnIrAlMenu.setOnClickListener(view -> {
            Intent intent = new Intent(BilleteraNequiActivity.this, BotonesActivity.class);
            startActivity(intent);
            finish();
        });
    }
}

