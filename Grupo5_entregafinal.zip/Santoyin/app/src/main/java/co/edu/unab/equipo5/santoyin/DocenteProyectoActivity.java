package co.edu.unab.equipo5.santoyin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class DocenteProyectoActivity extends AppCompatActivity {

    private Button btnNavigateCursosInformatica;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.docenteproyecto);

        btnNavigateCursosInformatica = findViewById(R.id.btn_navigate_cursos_informatica);
        btnNavigateCursosInformatica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DocenteProyectoActivity.this, BotonesActivity.class);
                startActivity(intent);
                finish(); // Opcional: Cierra la actividad actual
            }
        });
    }
}
