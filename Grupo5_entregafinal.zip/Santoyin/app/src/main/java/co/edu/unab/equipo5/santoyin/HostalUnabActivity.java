package co.edu.unab.equipo5.santoyin;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class HostalUnabActivity extends AppCompatActivity {

    private Button btnNavigateCursosInformatica;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hostalunab);

        btnNavigateCursosInformatica = findViewById(R.id.btn_navigate_cursos_informatica);
        btnNavigateCursosInformatica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HostalUnabActivity.this, BotonesActivity.class);
                startActivity(intent);
                finish(); // Opcional: Cierra la actividad actual
            }
        });
    }
}