package co.edu.unab.equipo5.santoyin;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class InicioActivity extends AppCompatActivity {

    private static final int SPLASH_SCREEN_DURATION = 5000; // Duración de la pantalla de inicio en milisegundos
    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inicioapp);

        // Reproducir sonido al iniciar la aplicación
        mediaPlayer = MediaPlayer.create(this, R.raw.inicio); // Asegúrate de tener un archivo de sonido en res/raw llamado tu_sonido.mp3
        mediaPlayer.start();

        // Configurar la animación
        ImageView logoImageView = findViewById(R.id.logoImageView);
        TextView byTextView = findViewById(R.id.byTextView);
        TextView unabTextView = findViewById(R.id.unabTextView);

        Animation logoAnimation = AnimationUtils.loadAnimation(this, R.anim.logo_anim);
        Animation byTextAnimation = AnimationUtils.loadAnimation(this, R.anim.by_text_anim);
        Animation unabTextAnimation = AnimationUtils.loadAnimation(this, R.anim.unab_text_anim);

        logoImageView.startAnimation(logoAnimation);
        byTextView.startAnimation(byTextAnimation);
        unabTextView.startAnimation(unabTextAnimation);

        // Configurar el retraso para pasar a la siguiente actividad después de 5 segundos
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(InicioActivity.this, RegistrarActivity.class); // Cambia a la actividad que desees
                startActivity(intent);
                finish(); // Finaliza la actividad actual
            }
        }, SPLASH_SCREEN_DURATION + 3000); // Ajusta el tiempo de duración total de las animaciones
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Libera el recurso del MediaPlayer al destruir la actividad
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
    }
}

