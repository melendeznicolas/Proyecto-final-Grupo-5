package co.edu.unab.equipo5.santoyin;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class BotonesActivity extends AppCompatActivity {

    private Button buttonBilleteraNequi;
    private Button buttonCalificaciones;
    private Button buttonContactosUnab;
    private Button buttoncursosinformatica;
    private Button buttoncursosingles;
    private Button buttondocenteproyecto;
    private Button buttoneventos_unab;
    private Button buttonehoraslibres;
    private Button buttonhostalunab;
    private Button buttoninformacionestudiante;
    private Button buttonnoticiasunab;
    private Button buttonporcentajecarrera;
    private Button buttonportalesunab;
    private Button buttonprogramasunab;
    private Button buttonvacantesunab;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.botones);

        buttonBilleteraNequi = findViewById(R.id.button_billetera_nequi);
        buttonCalificaciones = findViewById(R.id.button_calificaciones);
        buttonContactosUnab = findViewById(R.id.button_contactos_unab);
        buttoncursosinformatica = findViewById(R.id.button_cursos_informatica);
        buttoncursosingles = findViewById(R.id.button_cursos_ingles);
        buttondocenteproyecto = findViewById(R.id.button_docente_proyecto);
        buttoneventos_unab = findViewById(R.id.button_eventos_unab);
        buttonehoraslibres = findViewById(R.id.button_horas_libres);
        buttonhostalunab = findViewById(R.id.button_hostal_unab);
        buttoninformacionestudiante = findViewById(R.id.button_informacion_estudiante);
        buttonnoticiasunab = findViewById(R.id.button_noticias_unab);
        buttonporcentajecarrera = findViewById(R.id.button_porcentaje_carrera);
        buttonportalesunab = findViewById(R.id.button_portales_unab);
        buttonprogramasunab = findViewById(R.id.button_programas_unab);
        buttonvacantesunab = findViewById(R.id.button_vacantes_unab);


        buttonBilleteraNequi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, BilleteraNequiActivity.class);
                startActivity(intent);
            }
        });

        buttonCalificaciones.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, CalificacionesActivity.class);
                startActivity(intent);
            }
        });

        buttonContactosUnab.setOnClickListener(new View.OnClickListener() { // Añadido
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, ContactosUnabActivity.class);
                startActivity(intent);
            }
        });
        buttoncursosinformatica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, CursosInformaticaActivity.class);
                startActivity(intent);
            }
        });
        buttoncursosingles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, CursosInglesActivity.class);
                startActivity(intent);
            }
        });
        buttondocenteproyecto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, DocenteProyectoActivity.class);
                startActivity(intent);
            }
        });
        buttoneventos_unab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, EventosUnabActivity.class);
                startActivity(intent);
            }
        });

        buttonehoraslibres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, HorasLibresActivity.class);
                startActivity(intent);
            }
        });
        buttonhostalunab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, HostalUnabActivity.class);
                startActivity(intent);
            }
        });
        buttoninformacionestudiante.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, InformacionEstudianteActivity.class);
                startActivity(intent);
            }
        });
        buttonnoticiasunab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, NoticiasUnabActivity.class);
                startActivity(intent);
            }
        });
        buttonporcentajecarrera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, PorcentajeCarreraActivity.class);
                startActivity(intent);
            }
        });
        buttonportalesunab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, PortalesUnabActivity.class);
                startActivity(intent);
            }
        });
        buttonprogramasunab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, ProgramasUnabActivity.class);
                startActivity(intent);
            }
        });
        buttonvacantesunab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BotonesActivity.this, VacantesUnabActivity.class);
                startActivity(intent);
            }
        });
    }
}
